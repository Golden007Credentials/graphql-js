## GraphQL Subscription

The `graphql/subscription` module is responsible for subscribing to updates on specific data.

```js
import { subscribe, createSourceEventStream } from 'graphql/subscription'; // ES6
var GraphQLSubscription = require('graphql/subscription'); // CommonJS
```
