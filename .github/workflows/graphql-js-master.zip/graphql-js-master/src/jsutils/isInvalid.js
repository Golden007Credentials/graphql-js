// @flow strict

/**
 * Returns true if a value is undefined, or NaN.
 */
export default function isInvalid(value: mixed): boolean %checks {
  return value === undefined || value !== value;
}
