// @flow strict

/**
 * Returns the first argument it receives.
 */
export default function identityFunc<T>(x: T): T {
  return x;
}
