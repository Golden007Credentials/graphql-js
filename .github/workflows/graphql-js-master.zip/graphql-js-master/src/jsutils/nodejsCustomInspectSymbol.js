// @flow strict

const nodejsCustomInspectSymbol =
  typeof Symbol === 'function' && typeof Symbol.for === 'function'
    ? Symbol.for('nodejs.util.inspect.custom')
    : undefined;

export default nodejsCustomInspectSymbol;
