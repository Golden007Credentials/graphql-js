## JavaScript Utils

This directory contains dependency-free JavaScript utility functions used
throughout the codebase.

Each utility should belong in its own file and be the default export.

These functions are not part of the module interface and are subject to change.
