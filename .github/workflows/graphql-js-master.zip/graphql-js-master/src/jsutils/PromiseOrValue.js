// @flow strict

export type PromiseOrValue<+T> = Promise<T> | T;
