## GraphQL Validation

The `graphql/validation` module fulfills the Validation phase of fulfilling a
GraphQL result.

```js
import { validate } from 'graphql/validation'; // ES6
var GraphQLValidator = require('graphql/validation'); // CommonJS
```
