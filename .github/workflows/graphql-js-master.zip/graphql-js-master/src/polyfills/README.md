## Polyfills

This directory contains dependency-free polyfills for ES6 & ES7 functions used
throughout the codebase.

Each polyfill should belong in its own file and be the default export.

These functions are not part of the module interface and are subject to change.
