## GraphQL Utilities

The `graphql/utilities` module contains common useful computations to use with
the GraphQL language and type objects.

```js
import { ... } from 'graphql/utilities'; // ES6
var GraphQLUtilities = require('graphql/utilities'); // CommonJS
```
