## GraphQL Execution

The `graphql/execution` module is responsible for the execution phase of
fulfilling a GraphQL request.

```js
import { execute } from 'graphql/execution'; // ES6
var GraphQLExecution = require('graphql/execution'); // CommonJS
```
