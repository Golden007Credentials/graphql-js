## GraphQL Type System

The `graphql/type` module is responsible for defining GraphQL types and schema.

```js
import { ... } from 'graphql/type'; // ES6
var GraphQLType = require('graphql/type'); // CommonJS
```
