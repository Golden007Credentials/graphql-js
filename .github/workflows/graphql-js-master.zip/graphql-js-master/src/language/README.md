## GraphQL Language

The `graphql/language` module is responsible for parsing and operating on the
GraphQL language.

```js
import { ... } from 'graphql/language'; // ES6
var GraphQLLanguage = require('graphql/language'); // CommonJS
```
