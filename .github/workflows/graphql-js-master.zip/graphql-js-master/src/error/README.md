## GraphQL Errors

The `graphql/error` module is responsible for creating and formatting
GraphQL errors.

```js
import { ... } from 'graphql/error'; // ES6
var GraphQLError = require('graphql/error'); // CommonJS
```
